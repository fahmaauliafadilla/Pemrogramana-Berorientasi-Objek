/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author m s i
 */
public class Praktikum_PBO4 {

    public static void main(String[] args) {

        Mobil mobil1 = new Mobil("Toyota", 180, "Bensin", 4);

        mobil1.tampilkanInfoKendaraan();
        mobil1.tampilkanInfoMobil();
    }
}