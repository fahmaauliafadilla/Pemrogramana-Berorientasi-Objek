/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas4;

/**
 *
 * @author m s i
 */
public class Main {

    public static void main(String[] args) {

        Pekerja pekerja = new Pekerja(
                "Fahma",
                20,
                "Mahasiswa",
                3000000
        );

        System.out.println(pekerja.toString());

        pekerja.setNama("Vey");

        System.out.println(pekerja.toString());

        System.out.println("Usia: " + pekerja.usia);
        System.out.println("Pekerjaan: " + pekerja.pekerjaan);
        //System.out.print;m(pekerja.nama);
        //System.out.println(pekerja.usia);
        System.out.println(pekerja.pekerjaan);
    }
}
