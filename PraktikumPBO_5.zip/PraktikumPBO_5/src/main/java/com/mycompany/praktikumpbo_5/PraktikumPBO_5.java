/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.praktikumpbo_5;

/**
 *
 * @author m s i
 */
public class PraktikumPBO_5 {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
    