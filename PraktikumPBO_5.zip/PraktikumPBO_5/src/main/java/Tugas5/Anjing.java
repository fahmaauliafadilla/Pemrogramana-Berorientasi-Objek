/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author m s i
 */
class Anjing extends Hewan {

    public Anjing(String nama) {
        super(nama, "Anjing");
    }

    // Overriding method tampilkanInfo()
    @Override
    public void tampilkanInfo() {
        System.out.println("Nama : " + nama);
        System.out.println("Jenis : " + jenis);
        System.out.println("Suara : Guk guk");
    }

    // Method khusus Anjing
    public void suara() {
        System.out.println("Anjing bersuara: Guk guk!");
    }
}