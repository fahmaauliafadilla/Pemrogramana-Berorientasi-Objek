/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author m s i
 */
class Kucing extends Hewan {

    public Kucing(String nama) {
        super(nama, "Kucing");
    }

    // Overriding method tampilkanInfo()
    @Override
    public void tampilkanInfo() {
        System.out.println("Nama : " + nama);
        System.out.println("Jenis : " + jenis);
        System.out.println("Suara : Meong");
    }

    // Method khusus Kucing
    public void suara() {
        System.out.println("Kucing bersuara: Meong!");
    }
}
