/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author m s i
 */
public class Main {
     public static void main(String[] args) {
       
        Kucing kucing = new Kucing("Xavier");
        kucing.tampilkanInfo();
        kucing.suara();

        System.out.println();

        Anjing anjing = new Anjing("Puppy");
        anjing.tampilkanInfo();
        anjing.suara();
    }
}
